<?php

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$age = $_POST['age'];
$weight = $_POST['weight'];
$height = $_POST['height'];

$bmi = $weight / ($height * $height);

if($bmi < 18.5){
$status = "Underweight";
}
elseif($bmi < 25){
$status = "Normal";
}
elseif($bmi < 30){
$status = "Overweight";
}
else{
$status = "Obese";
}

header("Location: result.php?name=$firstname $lastname&bmi=$bmi&status=$status");

?>