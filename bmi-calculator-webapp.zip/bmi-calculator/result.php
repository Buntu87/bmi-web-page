<!DOCTYPE html>
<html>

<head>
<title>BMI Result</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

<h1>Your BMI Result</h1>

<?php

$name = $_GET['name'];
$bmi = $_GET['bmi'];
$status = $_GET['status'];

echo "<h2>$name</h2>";
echo "<p>BMI: ".round($bmi,2)."</p>";
echo "<p>Status: $status</p>";

?>

<a href="index.html">
<button>Calculate Again</button>
</a>

</div>

</body>

</html>