function calculateBMI() {
    let name = document.getElementById("name").value;
    let weight = document.getElementById("weight").value;
    let height = document.getElementById("height").value;

    let bmi = (weight / (height * height)).toFixed(2);

    document.getElementById("result").innerHTML = "BMI: " + bmi;

    fetch("save.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `name=${name}&weight=${weight}&height=${height}&bmi=${bmi}`
    });
}

function loadData() {
    fetch("fetch.php")
        .then(res => res.text())
        .then(data => {
            document.getElementById("table").innerHTML = data;
        });
}