CREATE DATABASE bmi_db;

USE bmi_db;

CREATE TABLE records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    weight FLOAT,
    height FLOAT,
    bmi FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);