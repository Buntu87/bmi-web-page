<?php
include 'db.php';

$sql = "SELECT * FROM records";
$result = $conn->query($sql);

echo "<tr><th>Name</th><th>Weight</th><th>Height</th><th>BMI</th></tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$row['name']}</td>
            <td>{$row['weight']}</td>
            <td>{$row['height']}</td>
            <td>{$row['bmi']}</td>
          </tr>";
}

$conn->close();
?>