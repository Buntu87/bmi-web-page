<?php
include 'db.php';

$name = $_POST['name'];
$weight = $_POST['weight'];
$height = $_POST['height'];
$bmi = $_POST['bmi'];

$sql = "INSERT INTO records (name, weight, height, bmi)
        VALUES ('$name', '$weight', '$height', '$bmi')";

$conn->query($sql);

$conn->close();
?>